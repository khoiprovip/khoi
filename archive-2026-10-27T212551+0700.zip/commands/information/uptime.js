const config = require('../../config/config.js')

module.exports = {
    name: 'uptime',
    category: 'information',
    /**
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        let totalSeconds = (Date.now() - config.startedAt) / 1000
        const days = Math.floor(totalSeconds / 86400)
        totalSeconds %= 86400
        const hours = Math.floor(totalSeconds / 3600)
        totalSeconds %= 3600
        const minutes = Math.floor(totalSeconds / 60)
        const seconds = Math.floor(totalSeconds % 60)

        api.sendMessage(`⏱ Bot đã chạy được: ${days} ngày ${hours} giờ ${minutes} phút ${seconds} giây.`, event.threadID)
    }
}
