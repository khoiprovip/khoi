const config = require('../../config/config.js')

module.exports = {
    name: 'restart',
    category: 'information',
    aliases: ['rs'],
    /**
     * Chỉ admin (config.adminIDs) mới dùng được. Cần chạy bằng `npm start` (supervisor) thì bot mới tự bật lại.
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     */
    run: (api, event) => {
        if (!config.adminIDs.includes(String(event.senderID))) return
        api.sendMessage('🔄 Đang restart bot...', event.threadID, () => process.exit(42))
        setTimeout(() => process.exit(42), 5000) // phòng khi callback không chạy
    }
}
