const config = require('../../config/config.js')
const muted = require('../../lib/muted.js')
const { resolveTargets } = require('../../lib/target.js')

const isAdmin = id => config.adminIDs.includes(String(id))
const MAX_PER_COMMAND = 3
const DURATION = /^(\d+)(m|h|d)$/i

function parseDuration(token) {
    const m = String(token).match(DURATION)
    return m ? Number(m[1]) * { m: 60e3, h: 3600e3, d: 86400e3 }[m[2].toLowerCase()] : 0
}

module.exports = {
    name: 'mute',
    category: 'information',
    aliases: ['khoamom', 'silence'],
    /**
     * "Khoá mõm": bot sẽ phớt lờ người đó (không trả lời, không nhận lệnh, không bắt tag) trong nhóm này.
     * Lưu ý: KHÔNG chặn được người đó nhắn tin trong nhóm (Messenger không cho bot làm việc đó).
     *   /mute @tên [30m|2h|1d]   /mute (reply tin nhắn) [thời gian]   /mute ds (xem danh sách)
     * Không ghi thời gian = đến khi /unmute. Chỉ admin bot dùng được.
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        if (!isAdmin(event.senderID)) return
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh này chỉ dùng trong nhóm.', event.threadID)

        if (['ds', 'list'].includes((args[0] || '').toLowerCase())) {
            const list = muted.list(event.threadID)
            if (!list.length) return api.sendMessage('ℹ️ Chưa ai bị khoá mõm trong nhóm này.', event.threadID)
            const fmtUntil = u => u === 0 ? 'đến khi /unmute' : `còn ${Math.max(1, Math.round((u - Date.now()) / 60000))} phút`
            const show = names => api.sendMessage('🔇 Đang bị khoá mõm:\n' + list.map(x => `- ${names[x.id]?.name || x.id} (${fmtUntil(x.until)})`).join('\n'), event.threadID)
            return typeof api.getUserInfo === 'function'
                ? api.getUserInfo(list.map(x => x.id), (err, users) => show(err ? {} : users))
                : show({})
        }

        const durationToken = args.find(a => DURATION.test(a))
        const durationMs = durationToken ? parseDuration(durationToken) : 0
        const nameArgs = args.filter(a => a !== durationToken)

        const botID = String(api.getCurrentUserID())
        resolveTargets(api, event, nameArgs, ({ ids, ambiguous }) => {
            if (ambiguous)
                return api.sendMessage(`❎ Có nhiều người trùng tên "${ambiguous}". Reply tin nhắn của đúng người đó rồi gõ /mute.`, event.threadID, event.messageID)

            // Không bao giờ khoá: bot, chính người gõ lệnh, các admin
            const list = [...ids].filter(id => id !== botID && id !== String(event.senderID) && !isAdmin(id))
            if (!list.length)
                return api.sendMessage(ids.size
                    ? '❎ Người bạn chọn là bạn, bot hoặc admin nên không khoá mõm được.'
                    : '❎ Không tìm thấy người cần khoá mõm. Tag (bấm chọn tên trong gợi ý), gõ tên, hoặc reply tin nhắn của họ rồi gõ /mute.', event.threadID, event.messageID)
            if (list.length > MAX_PER_COMMAND)
                return api.sendMessage(`❎ Mỗi lần chỉ khoá tối đa ${MAX_PER_COMMAND} người.`, event.threadID, event.messageID)

            list.forEach(id => muted.add(event.threadID, id, durationMs))
            const label = durationMs ? `trong ${durationToken}` : 'cho đến khi /unmute'
            api.sendMessage(`🔇 Đã khoá mõm ${list.length} người ${label}: bot sẽ phớt lờ họ trong nhóm này. (Họ vẫn nhắn được trong nhóm, bot không chặn được việc đó.)`, event.threadID, event.messageID)
        })
    }
}
