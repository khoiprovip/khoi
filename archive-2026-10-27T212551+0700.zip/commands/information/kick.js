const config = require('../../config/config.js')

// Giống /rs: chỉ ID trong config.adminIDs mới dùng được
const isAdmin = id => config.adminIDs.includes(String(id))

const MAX_PER_COMMAND = 3
// Bỏ dấu + chữ thường để so tên (vd "Moshi" khớp "moshi")
const norm = t => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi, 'd').toLowerCase().trim()

// Mỗi bản fca đặt tên hàm kick khác nhau -> tự dò theo tên. Không có thì thử đường cũ của Facebook (httpPost).
function kickUser(api, userID, threadID, callback) {
    const names = ['removeUserFromGroup', 'removeUser', 'kickUser', 'removeParticipant', 'removeMember', 'removeFromGroup']
    // Một số bản fca gộp add/kick vào 1 hàm gcmember('add'|'remove', userID, threadID, cb)
    if (typeof api.gcmember === 'function') {
        try { return api.gcmember('remove', [userID], threadID, callback) } catch (error) { return callback(error) }
    }

    const found = names.find(n => typeof api[n] === 'function')
        || Object.keys(api).find(k => /(remove|kick)/i.test(k) && typeof api[k] === 'function')

    if (found) {
        try { return api[found](userID, threadID, callback) } catch (error) { return callback(error) }
    }

    // In danh sách hàm của thư viện ra Console để biết thư viện này có hàm kick tên gì
    console.error('[kick] Không có hàm kick. Các hàm thư viện có:', Object.keys(api).filter(k => typeof api[k] === 'function').join(', '))

    if (typeof api.httpPost === 'function') {
        return api.httpPost('https://www.facebook.com/chat/remove_participants/', { uid: userID, tid: threadID }, (err, body) => {
            if (err) return callback(err)
            const text = String(body || '')
            if (/"error"/.test(text) && !/"error":\s*0/.test(text)) return callback(new Error('Facebook từ chối (cách kick cũ không còn hoạt động)'))
            callback()
        })
    }
    callback(new Error('thư viện đăng nhập không có hàm kick'))
}

module.exports = {
    name: 'kick',
    category: 'information',
    aliases: ['remove'],
    /**
     * Kick người khỏi nhóm chat. Chỉ admin bot dùng được, chỉ dùng trong nhóm.
     * Cách dùng: /kick @tên (tag 1-3 người)  |  reply tin nhắn của người đó rồi gõ /kick  |  /kick <uid>
     * Bot cần có quyền kick trong nhóm (thường phải là quản trị viên nhóm nếu nhóm bật chế độ quản trị viên).
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        if (!isAdmin(event.senderID)) return // người không phải admin: im lặng
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh kick chỉ dùng trong nhóm.', event.threadID)
        const botID = String(api.getCurrentUserID())
        const requested = new Set(Object.keys(event.mentions || {}))
        if (event.messageReply?.senderID) requested.add(String(event.messageReply.senderID))
        for (const a of args) if (/^\d{6,}$/.test(a)) requested.add(a)

        console.log('[kick] mentions:', JSON.stringify(event.mentions || {}), '| reply:', event.messageReply?.senderID || '-')

        const proceed = ids => {
            // Không bao giờ kick: chính bot, chính người gõ lệnh, các admin bot
            const list = [...ids].filter(id => id !== botID && id !== String(event.senderID) && !isAdmin(id))

            if (!list.length) {
                const why = ids.size
                    ? '❎ Người bạn chọn là bạn, bot hoặc admin của bot nên không kick được.'
                    : '❎ Không tìm thấy người cần kick. Gõ @ rồi bấm CHỌN tên trong gợi ý (đừng gõ tay), hoặc reply tin nhắn của họ rồi gõ /kick.'
                return api.sendMessage(why, event.threadID, event.messageID)
            }
            if (list.length > MAX_PER_COMMAND)
                return api.sendMessage(`❎ Mỗi lần chỉ kick tối đa ${MAX_PER_COMMAND} người.`, event.threadID, event.messageID)
            doKick(list)
        }

        // Không nhận được tag/reply/uid (vd gõ tay "@tên") -> tìm theo TÊN trong danh sách thành viên nhóm
        const typedName = norm(args.join(' ').replace(/@/g, ''))
        if (!requested.size && typedName && typeof api.getThreadInfo === 'function' && typeof api.getUserInfo === 'function') {
            return api.getThreadInfo(event.threadID, (err, info) => {
                if (err || !info?.participantIDs) return proceed(requested)
                api.getUserInfo(info.participantIDs, (err2, users) => {
                    if (err2 || !users) return proceed(requested)
                    const found = info.participantIDs.filter(id => norm(users[id]?.name || '').includes(typedName))
                    if (found.length > 1)
                        return api.sendMessage(`❎ Có ${found.length} người trùng tên "${args.join(' ')}". Hãy reply tin nhắn của đúng người đó rồi gõ /kick.`, event.threadID, event.messageID)
                    proceed(new Set(found))
                })
            })
        }
        proceed(requested)

        function doKick(list) {
        // Kick lần lượt, cách nhau vài giây (kick dồn dập rất dễ bị Facebook nghi là bot)
        list.forEach((id, i) => setTimeout(() => {
            kickUser(api, id, event.threadID, err => {
                if (err) {
                    console.error('Lỗi kick:', err.message || err)
                    return api.sendMessage(`❎ Kick không được: ${err.message || 'lỗi không rõ'}. Bot cần là quản trị viên của nhóm (hoặc người đó là admin nhóm).`, event.threadID)
                }
                api.sendMessage('✅ Đã kick.', event.threadID)
            })
        }, i * 3000 + Math.floor(Math.random() * 1500)))
        }
    }
}
