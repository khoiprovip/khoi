const config = require('../../config/config.js')

const isAdmin = id => config.adminIDs.includes(String(id))
const MAX_LEN = 100

// Mỗi bản fca đặt tên hàm khác nhau -> tự dò
function findTitleFn(api) {
    const names = ['setTitle', 'changeThreadTitle', 'setThreadTitle', 'changeGroupName', 'changeTitle', 'setGroupName']
    return names.find(n => typeof api[n] === 'function')
        || Object.keys(api).find(k => /(title|groupname)/i.test(k) && typeof api[k] === 'function')
}

module.exports = {
    name: 'doiten',
    category: 'information',
    aliases: ['tennhom', 'settitle', 'rename'],
    /**
     * Đổi TÊN NHÓM chat. Chỉ admin bot dùng được, chỉ dùng trong nhóm.
     *   /doiten Tên nhóm mới
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        if (!isAdmin(event.senderID)) return
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh này chỉ dùng trong nhóm.', event.threadID)

        const title = args.join(' ').trim()
        if (!title)
            return api.sendMessage('❎ Nhập tên mới. Ví dụ: /doiten Hội bạn thân', event.threadID, event.messageID)
        if (title.length > MAX_LEN)
            return api.sendMessage(`❎ Tên nhóm tối đa ${MAX_LEN} ký tự.`, event.threadID, event.messageID)

        const fn = findTitleFn(api)
        if (!fn) {
            console.error('[doiten] Không có hàm đổi tên nhóm. Các hàm thư viện có:', Object.keys(api).filter(k => typeof api[k] === 'function').join(', '))
            return api.sendMessage('❎ Thư viện đăng nhập hiện tại không có hàm đổi tên nhóm.', event.threadID, event.messageID)
        }

        try {
            api[fn](title, event.threadID, err => {
                if (err) {
                    console.error('Lỗi đổi tên nhóm:', err.message || err)
                    return api.sendMessage(`❎ Không đổi được tên nhóm: ${err.message || 'lỗi không rõ'}. Nếu nhóm bật chế độ quản trị viên thì acc bot phải là quản trị viên.`, event.threadID)
                }
                // Facebook tự hiện thông báo đổi tên trong nhóm, không cần nhắn thêm
            })
        } catch (error) {
            api.sendMessage(`❎ Không đổi được tên nhóm: ${error.message}`, event.threadID)
        }
    }
}
