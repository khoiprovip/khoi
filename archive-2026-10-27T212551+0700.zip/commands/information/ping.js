module.exports = {
    name: 'ping',
    category: 'information',
    /**
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        const sentAt = Number(event.timestamp) || Date.now()
        const ping = Date.now() - sentAt
        api.sendMessage(`🚀 Ping hiện tại của bot là: ${ping}ms.`, event.threadID)
    }
}
