const config = require('../../config/config.js')
const tracker = require('../../lib/tracker.js')
const { callAI } = require('../../lib/ai.js')
const { NO_LATEX_RULE } = require('../../lib/geometry.js')
const { cooldownLeft, startCooldown, globalQuotaLeft, sendHuman } = require('../../lib/humanize.js')

// Model riêng cho việc tóm tắt (khác model chính). Đổi tên model ở đây hoặc đặt aiSummaryModel trong config.js
const SUMMARY_MODEL = () => config.aiSummaryModel || 'deepseek-v4-flash'

const MAX_CHARS = 20000   // giới hạn độ dài đưa vào AI (cắt bớt tin cũ nhất)
const MIN_MESSAGES = 5

const SYSTEM = `Bạn tóm tắt cuộc trò chuyện của một nhóm chat Messenger bằng tiếng Việt cho người vắng mặt đọc nhanh.
- CHỈ dựa vào các tin nhắn được đưa, không bịa, không suy diễn thêm.
- Trình bày ngắn gọn (dưới 250 từ), theo thứ tự: chủ đề chính; quyết định/kế hoạch (nếu có); việc cần làm và ai làm (nếu có); điều đáng chú ý khác. Phần nào không có thì bỏ qua.
- Gọi người theo tên đã ghi trong tin nhắn. Nếu phần lớn là tán gẫu thì nói ngắn gọn là chủ yếu tán gẫu và nêu 1-2 ý chính.
${NO_LATEX_RULE}`

const VN_OFFSET = 7 * 3600 * 1000
const fmt = t => new Date(t).toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh', hour12: false, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })

/** "50" -> 50 tin cuối | "6h" "2d" -> khoảng thời gian | "homnay" -> từ 0h hôm nay (giờ VN) */
function parseRange(args) {
    const t = args.join('').toLowerCase().replace(/\s/g, '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    const now = Date.now()
    if (/^\d+$/.test(t) && t) return { limit: Math.min(Number(t), 500), sinceMs: 0, label: `${Math.min(Number(t), 500)} tin gần nhất` }
    const m = t.match(/^(\d+)(h|d)$/)
    if (m) {
        const ms = Number(m[1]) * (m[2] === 'h' ? 3600e3 : 86400e3)
        return { limit: 500, sinceMs: now - Math.min(ms, 14 * 86400e3), label: `${m[1]}${m[2] === 'h' ? ' giờ' : ' ngày'} qua` }
    }
    if (t === 'homnay' || t === 'today') return { limit: 500, sinceMs: Math.floor((now + VN_OFFSET) / 86400e3) * 86400e3 - VN_OFFSET, label: 'hôm nay' }
    return { limit: 300, sinceMs: now - 86400e3, label: '24 giờ qua' }
}

module.exports = {
    name: 'tomtat',
    category: 'information',
    aliases: ['tt', 'tonghop', 'sum', 'summary'],
    /**
     * Tổng hợp tin nhắn đã ghi của nhóm (phải bật /theodoi bat trước).
     *   /tomtat            -> 24 giờ qua    /tomtat 100 -> 100 tin gần nhất
     *   /tomtat 6h | 2d    -> 6 giờ / 2 ngày qua      /tomtat homnay
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: async (api, event, args) => {
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh này chỉ dùng trong nhóm.', event.threadID)
        if (!tracker.isEnabled(event.threadID))
            return api.sendMessage('❎ Nhóm này chưa bật theo dõi tin nhắn. Admin gõ /theodoi bat trước, sau đó bot mới có tin để tổng hợp.', event.threadID, event.messageID)

        const userKey = `${event.threadID}:${event.senderID}`
        if (config.ratelimit.has(userKey) || cooldownLeft(userKey) > 0 || !globalQuotaLeft()) return

        const range = parseRange(args)
        const messages = tracker.read(event.threadID, range)
        if (messages.length < MIN_MESSAGES)
            return api.sendMessage(`❎ Mới có ${messages.length} tin trong khoảng "${range.label}", chưa đủ để tổng hợp.`, event.threadID, event.messageID)

        config.ratelimit.set(userKey, true)
        try {
            const nameOf = await tracker.resolveNames(api, messages.map(m => m.u))
            let lines = messages.map(m => `[${fmt(m.t)}] ${nameOf(m.u)}: ${m.m.replace(/\s+/g, ' ')}`)

            // Quá dài thì bỏ bớt tin cũ nhất
            let total = lines.reduce((n, l) => n + l.length + 1, 0)
            while (total > MAX_CHARS && lines.length > MIN_MESSAGES) total -= lines.shift().length + 1

            const summary = await callAI({
                model: SUMMARY_MODEL(),
                messages: [
                    { role: 'system', content: SYSTEM },
                    { role: 'user', content: `Các tin nhắn trong nhóm (${range.label}):\n${lines.join('\n')}` }
                ],
                maxTokens: 1500,
                temperature: 0.3
            })

            const header = `📋 Tổng hợp ${lines.length} tin (${range.label}, ${fmt(messages[messages.length - lines.length].t)} → ${fmt(messages[messages.length - 1].t)})\n\n`
            return await sendHuman(api, header + summary, event.threadID, event.messageID)
        } catch (error) {
            console.error(error)
            api.sendMessage('❎ Có lỗi khi tổng hợp, thử lại sau nhé.', event.threadID)
        } finally {
            startCooldown(userKey)
            config.ratelimit.delete(userKey)
        }
    }
}
