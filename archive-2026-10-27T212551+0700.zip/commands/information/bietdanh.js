const config = require('../../config/config.js')
const { resolveTargets } = require('../../lib/target.js')

const isAdmin = id => true
const MAX_LEN = 100

function findNicknameFn(api) {
    const names = ['changeNickname', 'setNickname', 'changeNick', 'nickname']
    return names.find(n => typeof api[n] === 'function')
        || Object.keys(api).find(k => /nick/i.test(k) && typeof api[k] === 'function')
}

module.exports = {
    name: 'bietdanh',
    category: 'information',
    aliases: ['bd', 'nickname', 'nick'],
    /**
     * Đổi BIỆT DANH của thành viên trong nhóm. Chỉ admin bot dùng được, chỉ dùng trong nhóm.
     *   /bietdanh Cu Li                    -> đổi biệt danh của CHÍNH BẠN
     *   (reply tin nhắn của họ) /bietdanh Cu Li   -> đổi của người được reply
     *   /bietdanh Moshi | Cu Li            -> tìm người tên "Moshi" rồi đặt biệt danh "Cu Li" (dấu | ngăn tên và biệt danh)
     *   /bietdanh @tên Cu Li               -> nếu bot nhận được tag
     *   thêm "xoa" (vd /bietdanh Moshi | xoa) để XOÁ biệt danh
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        if (!isAdmin(event.senderID)) return
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh này chỉ dùng trong nhóm.', event.threadID)

        const fn = findNicknameFn(api)
        if (!fn) {
            console.error('[bietdanh] Không có hàm đổi biệt danh. Các hàm thư viện có:', Object.keys(api).filter(k => typeof api[k] === 'function').join(', '))
            return api.sendMessage('❎ Thư viện đăng nhập hiện tại không có hàm đổi biệt danh.', event.threadID, event.messageID)
        }

        let text = args.join(' ').trim()
        let nameArgs = []
        let nickname

        if (text.includes('|')) {
            // "tên | biệt danh"
            const [left, ...rest] = text.split('|')
            nameArgs = left.trim().split(/\s+/).filter(Boolean)
            nickname = rest.join('|').trim()
        } else {
            // Bỏ phần "@tên" của các tag (nếu có) khỏi biệt danh
            for (const label of Object.values(event.mentions || {})) text = text.split(String(label)).join(' ')
            nickname = text.replace(/\s+/g, ' ').trim()
        }

        if (/^(xoa|xóa|reset)$/i.test(nickname)) nickname = '' // '' = xoá biệt danh
        if (nickname === undefined || (nickname === '' && !/xoa|xóa|reset/i.test(args.join(' ')) && !text.includes('|')))
            return api.sendMessage('❎ Nhập biệt danh. Ví dụ: /bietdanh Cu Li  hoặc  /bietdanh Moshi | Cu Li  (xoá: /bietdanh Moshi | xoa)', event.threadID, event.messageID)
        if (nickname.length > MAX_LEN)
            return api.sendMessage(`❎ Biệt danh tối đa ${MAX_LEN} ký tự.`, event.threadID, event.messageID)

        const apply = ids => {
            if (!ids.length)
                return api.sendMessage('❎ Không tìm thấy người cần đổi biệt danh. Reply tin nhắn của họ, hoặc gõ /bietdanh tên | biệt danh.', event.threadID, event.messageID)
            if (ids.length > 3)
                return api.sendMessage('❎ Mỗi lần chỉ đổi tối đa 3 người.', event.threadID, event.messageID)

            // Cách nhau vài giây để không bị nghi là bot
            ids.forEach((id, i) => setTimeout(() => {
                try {
                    api[fn](nickname, event.threadID, id, err => {
                        if (err) {
                            console.error('Lỗi đổi biệt danh:', err.message || err)
                            api.sendMessage(`❎ Không đổi được biệt danh: ${err.message || 'lỗi không rõ'}.`, event.threadID)
                        }
                    })
                } catch (error) {
                    api.sendMessage(`❎ Không đổi được biệt danh: ${error.message}`, event.threadID)
                }
            }, i * 2500 + Math.floor(Math.random() * 1000)))
        }

        const hasTarget = nameArgs.length || Object.keys(event.mentions || {}).length || event.messageReply?.senderID
        if (!hasTarget) return apply([String(event.senderID)]) // không chọn ai -> đổi của chính người gõ

        resolveTargets(api, event, nameArgs, ({ ids, ambiguous }) => {
            if (ambiguous)
                return api.sendMessage(`❎ Có nhiều người trùng tên "${ambiguous}". Reply tin nhắn của đúng người đó rồi gõ /bietdanh.`, event.threadID, event.messageID)
            apply([...ids])
        })
    }
}
