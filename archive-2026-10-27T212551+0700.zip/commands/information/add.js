const config = require('../../config/config.js')

// Giống /rs và /kick: chỉ ID trong config.adminIDs mới dùng được
const isAdmin = id => config.adminIDs.includes(String(id))

const MAX_PER_COMMAND = 3

// Mỗi bản fca đặt tên hàm khác nhau -> tự dò theo tên
function findAddFn(api) {
    // Một số bản fca (ws3-fca và các bản fork) gộp add/kick vào 1 hàm gcmember('add'|'remove', userID, threadID, cb)
    if (typeof api.gcmember === 'function') return 'gcmember'
    const names = ['addUserToGroup', 'addUser', 'addParticipant', 'addMember', 'addToGroup']
    return names.find(n => typeof api[n] === 'function')
        || Object.keys(api).find(k => /^add(user|member|participant)/i.test(k) && typeof api[k] === 'function')
}

// Lấy UID từ 1 đoạn người dùng gõ: số UID, link profile.php?id=..., hoặc link facebook.com/tên (tra qua api.getUID)
function resolveUID(api, text, callback) {
    if (/^\d{6,}$/.test(text)) return callback(null, text)

    const byId = text.match(/[?&]id=(\d{6,})/)
    if (byId) return callback(null, byId[1])

    if (/facebook\.com|fb\.com|fb\.me/i.test(text)) {
        if (typeof api.getUID !== 'function') return callback(new Error('thư viện không tra được UID từ link, hãy gửi UID dạng số'))
        return api.getUID(text, (err, uid) => err || !uid ? callback(new Error('không tra được UID từ link')) : callback(null, String(uid)))
    }
    callback(new Error('không hiểu'))
}

module.exports = {
    name: 'add',
    category: 'information',
    aliases: ['them'],
    /**
     * Thêm người vào nhóm chat. Chỉ admin bot dùng được, chỉ dùng trong nhóm.
     * Cách dùng: /add <uid>  |  /add <link facebook của người đó>  (tối đa 3 người, cách nhau dấu cách)
     * Facebook thường chỉ cho thêm người đã là BẠN BÈ của acc bot.
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        if (!isAdmin(event.senderID)) return // người không phải admin: im lặng
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh add chỉ dùng trong nhóm.', event.threadID)

        const inputs = args.filter(Boolean).slice(0, MAX_PER_COMMAND + 1)
        if (!inputs.length)
            return api.sendMessage('❎ Nhập UID hoặc link Facebook của người cần thêm. Ví dụ: /add 100012345678901', event.threadID, event.messageID)
        if (inputs.length > MAX_PER_COMMAND)
            return api.sendMessage(`❎ Mỗi lần chỉ thêm tối đa ${MAX_PER_COMMAND} người.`, event.threadID, event.messageID)

        const fn = findAddFn(api)
        if (!fn) {
            console.error('[add] Không có hàm thêm thành viên. Các hàm thư viện có:', Object.keys(api).filter(k => typeof api[k] === 'function').join(', '))
            return api.sendMessage('❎ Thư viện đăng nhập hiện tại không có hàm thêm thành viên.', event.threadID, event.messageID)
        }

        // Thêm lần lượt, cách nhau vài giây (dồn dập dễ bị Facebook nghi là bot)
        inputs.forEach((input, i) => setTimeout(() => {
            resolveUID(api, input, (err, uid) => {
                if (err) return api.sendMessage(`❎ "${input}": ${err.message}.`, event.threadID)
                try {
                    const done = err2 => {
                        if (err2) {
                            console.error('Lỗi add:', err2.message || err2)
                            return api.sendMessage(`❎ Không thêm được ${uid}: ${err2.message || 'lỗi không rõ'}. Thường do chưa là bạn bè với acc bot, hoặc người đó đã ở trong nhóm / chặn thêm vào nhóm.`, event.threadID)
                        }
                        api.sendMessage(`✅ Đã thêm ${uid} vào nhóm.`, event.threadID)
                    }
                    if (fn === 'gcmember') api.gcmember('add', [uid], event.threadID, done)
                    else api[fn](uid, event.threadID, done)
                } catch (error) {
                    api.sendMessage(`❎ Không thêm được ${uid}: ${error.message}`, event.threadID)
                }
            })
        }, i * 3000 + Math.floor(Math.random() * 1500)))
    }
}
