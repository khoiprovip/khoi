const config = require('../../config/config.js')
const muted = require('../../lib/muted.js')
const { resolveTargets } = require('../../lib/target.js')

const isAdmin = id => config.adminIDs.includes(String(id))

module.exports = {
    name: 'unmute',
    category: 'information',
    aliases: ['mommo', 'unsilence'],
    /**
     * Gỡ khoá mõm. /unmute @tên  |  reply tin nhắn rồi /unmute  |  /unmute all (gỡ tất cả trong nhóm)
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        if (!isAdmin(event.senderID)) return
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh này chỉ dùng trong nhóm.', event.threadID)

        if ((args[0] || '').toLowerCase() === 'all') {
            muted.clearThread(event.threadID)
            return api.sendMessage('🔊 Đã gỡ khoá mõm tất cả mọi người trong nhóm.', event.threadID, event.messageID)
        }

        resolveTargets(api, event, args, ({ ids, ambiguous }) => {
            if (ambiguous)
                return api.sendMessage(`❎ Có nhiều người trùng tên "${ambiguous}". Reply tin nhắn của đúng người đó rồi gõ /unmute.`, event.threadID, event.messageID)
            const list = [...ids].filter(id => muted.isMuted(event.threadID, id))
            if (!list.length)
                return api.sendMessage('❎ Không thấy người nào đang bị khoá mõm khớp với bạn chọn. Xem danh sách bằng /mute ds.', event.threadID, event.messageID)
            list.forEach(id => muted.remove(event.threadID, id))
            api.sendMessage(`🔊 Đã gỡ khoá mõm ${list.length} người.`, event.threadID, event.messageID)
        })
    }
}
