const config = require('../../config/config.js')
const tracker = require('../../lib/tracker.js')

const isAdmin = id => config.adminIDs.includes(String(id))

module.exports = {
    name: 'theodoi',
    category: 'information',
    aliases: ['track', 'follow'],
    /**
     * Bật/tắt ghi nhận tin nhắn chữ của nhóm để /tomtat tổng hợp. Chỉ admin bot dùng được.
     *   /theodoi bat  |  /theodoi tat  |  /theodoi xoa (tắt + xoá dữ liệu đã ghi)  |  /theodoi tt (trạng thái)
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        if (!isAdmin(event.senderID)) return
        if (event.isGroup === false)
            return api.sendMessage('❎ Lệnh này chỉ dùng trong nhóm.', event.threadID)

        const sub = (args[0] || 'tt').toLowerCase()
        const on = tracker.isEnabled(event.threadID)

        if (['bat', 'on', 'bật'].includes(sub)) {
            if (on) return api.sendMessage('ℹ️ Nhóm này đang được theo dõi rồi.', event.threadID)
            tracker.enable(event.threadID, event.senderID)
            // Thông báo công khai để mọi người trong nhóm biết
            return api.sendMessage('📝 Bot bắt đầu ghi nhận TIN NHẮN CHỮ của nhóm này để tổng hợp khi cần (dùng /tomtat). Dữ liệu chỉ lưu trên máy chủ của bot, giữ tối đa 14 ngày, không lưu ảnh/file. Admin tắt bằng /theodoi tat, xoá bằng /theodoi xoa.', event.threadID)
        }

        if (['tat', 'off', 'tắt'].includes(sub)) {
            tracker.disable(event.threadID)
            return api.sendMessage('⏹️ Đã tắt theo dõi. Tin cũ vẫn còn, xoá bằng /theodoi xoa.', event.threadID)
        }

        if (['xoa', 'xóa', 'clear'].includes(sub)) {
            tracker.disable(event.threadID)
            tracker.clearLog(event.threadID)
            return api.sendMessage('🗑️ Đã tắt theo dõi và xoá toàn bộ tin đã ghi của nhóm này.', event.threadID)
        }

        return api.sendMessage(`ℹ️ Theo dõi: ${on ? 'ĐANG BẬT' : 'đang tắt'} · Đã ghi ${tracker.count(event.threadID)} tin.\nDùng: /theodoi bat | tat | xoa`, event.threadID)
    }
}
