const config = require('../../config/config.js')
const { callAI } = require('../../lib/ai.js')
const { NO_LATEX_RULE } = require('../../lib/geometry.js')
const { cooldownLeft, startCooldown, globalQuotaLeft, sendHuman } = require('../../lib/humanize.js')

const OUTLINES = require('../../lib/outlines.js')

const SYSTEM = `Bạn là giáo viên Ngữ văn giỏi, giúp học sinh Việt Nam viết văn đúng dàn ý của thầy cô.
- Nếu đề thuộc một trong 3 dạng có trong DÀN Ý bên dưới (phân tích nhân vật; nghị luận về một vấn đề cần giải quyết; phân tích bài thơ/đoạn thơ) thì BẮT BUỘC làm đúng bố cục và thứ tự ý của dàn ý đó, không bỏ ý, không thêm phần thừa.
- Nếu đề không thuộc dạng nào thì viết theo bố cục thông thường (mở - thân - kết).
- Nếu người dùng chỉ xin "dàn ý" thì trả về dàn ý ngắn gọn theo mẫu, không viết thành bài.
- Câu văn trôi chảy, giàu hình ảnh, lập luận và dẫn chứng cụ thể, không viết chung chung sáo rỗng. Độ dài theo yêu cầu của người dùng, nếu không nói thì theo dàn ý (đoạn văn khoảng 250-300 chữ).
- Tuyệt đối KHÔNG bịa trích dẫn thơ/văn, chi tiết trong tác phẩm, số liệu hay tên tác giả. Không chắc chính xác thì nói thẳng là không chắc, chỉ nêu ý, và nhắc người dùng đối chiếu sách giáo khoa. Thiếu dữ kiện về tác phẩm (đề không nêu rõ) thì hỏi lại một câu ngắn thay vì tự bịa.
- Không dùng Markdown (không **, #, -). Chia đoạn bằng xuống dòng, trừ dạng "đoạn văn" thì viết liền một đoạn. Viết xong dừng, không giải thích thêm.
${NO_LATEX_RULE}

DÀN Ý:
${OUTLINES}`

module.exports = {
    name: 'van',
    category: 'fun',
    aliases: ['viet', 'writing'],
    /**
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: async (api, event, args) => {
        if (!args.length)
            return api.sendMessage('❎ Nhập đề văn. Ví dụ: /van viết đoạn văn phân tích nhân vật bé Em trong truyện Áo Tết', event.threadID)

        const userKey = `${event.threadID}:${event.senderID}`
        if (config.ratelimit.has(userKey) || cooldownLeft(userKey) > 0 || !globalQuotaLeft()) return

        config.ratelimit.set(userKey, true)
        try {
            const text = await callAI({
                messages: [{ role: 'system', content: SYSTEM }, { role: 'user', content: args.join(' ') }],
                maxTokens: 4500,
                temperature: 0.8
            })
            return await sendHuman(api, text, event.threadID, event.messageID)
        } catch (error) {
            console.error(error)
            api.sendMessage('❎ Có lỗi khi gọi AI, thử lại sau nhé.', event.threadID)
        } finally {
            startCooldown(userKey)
            config.ratelimit.delete(userKey)
        }
    }
}
