const config = require('../../config/config.js')
const { cooldownLeft, startCooldown, globalQuotaLeft, sendHuman } = require('../../lib/humanize.js')
const { callAI } = require('../../lib/ai.js')
const { getFigure, renderFigureStream, NO_LATEX_RULE } = require('../../lib/geometry.js')

// Lệnh /hinh vẫn giữ riêng để dùng khi muốn CHẮC CHẮN có lời giải + hình,
// khác với /ask (chat chung, tự động vẽ hình khi phát hiện bài hình học).
module.exports = {
    name: 'hinh',
    category: 'fun',
    aliases: ['geo', 'hinhhoc'],
    /**
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
    */
    run: async (api, event, args) => {
        if (!args.length) return api.sendMessage('❎ Nhập đề bài hình học đi. Ví dụ: /hinh tam giác ABC vuông tại A, AB=3, AC=4, tính BC', event.threadID)

        const userKey = `${event.threadID}:${event.senderID}`
        if (config.ratelimit.has(userKey) || cooldownLeft(userKey) > 0 || !globalQuotaLeft()) return

        config.ratelimit.set(userKey, true)

        try {
            const problem = args.join(' ')

            // Lời giải bằng chữ
            const answer = await callAI({
                messages: [
                    { role: 'system', content: `Bạn là trợ lý giải toán, trả lời ngắn gọn, từng bước, chính xác. ${NO_LATEX_RULE}` },
                    { role: 'user', content: problem }
                ],
                maxTokens: 2048,
                temperature: 0.2
            })

            // Hình vẽ (AI lấy toạ độ + QuickChart vẽ)
            const figure = await getFigure(problem)
            if (!figure) return sendHuman(api, answer, event.threadID, event.messageID)

            const stream = await renderFigureStream(figure)
            return sendHuman(api, { body: answer, attachment: stream }, event.threadID, event.messageID)
        } catch (error) {
            console.error(error)
            api.sendMessage('❎ Có lỗi khi giải/vẽ hình, thử lại sau nhé.', event.threadID)
        } finally {
            startCooldown(userKey)
        config.ratelimit.delete(userKey)
        }
    }
}
