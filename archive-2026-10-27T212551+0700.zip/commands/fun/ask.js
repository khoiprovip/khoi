const { answer } = require('../../lib/ai.js')

module.exports = {
    name: 'ask',
    category: 'fun',
    aliases: ['askgpt'],
    /**
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
    */
    run: (api, event, args) => answer(api, event, args.join(' '))
}
