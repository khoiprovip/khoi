module.exports = {
    name: 'roll',
    category: 'fun',
    /**
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
     */
    run: (api, event, args) => {
        let start = 100
        if (args[0]) {
            const number = Number(args[0])
            if (!Number.isInteger(number) || number < 0)
                return api.sendMessage('❎ Số không hợp lệ.', event.threadID)

            start = number
        }

        const end = start * 10
        const result = Math.floor(Math.random() * (end - start + 1)) + start
        return api.sendMessage(`🎲 Con số may mắn của bạn là: ${result}`, event.threadID)
    }
}
