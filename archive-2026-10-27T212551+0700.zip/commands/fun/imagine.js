const config = require('../../config/config.js')
const { cooldownLeft, startCooldown, globalQuotaLeft, sendHuman } = require('../../lib/humanize.js')
const axios = require('axios')
const { Readable } = require('stream')

module.exports = {
    name: 'imagine',
    category: 'fun',
    aliases: ['image', 've'],
    /**
     * @arg {import('ws3-fca').API} api
     * @arg {object} event
     * @arg {string[]} args
    */
    run: async (api, event, args) => {
        if (!args.length) return api.sendMessage('❎ Hãy nhập mô tả ảnh bạn muốn tạo. Ví dụ: /imagine mèo phi hành gia', event.threadID)

        const userKey = `${event.threadID}:${event.senderID}`
        if (config.ratelimit.has(userKey) || cooldownLeft(userKey) > 0 || !globalQuotaLeft()) return

        const prompt = args.join(' ')
        config.ratelimit.set(userKey, true)

        try {
            // Pollinations.ai: GET request trả thẳng về bytes ảnh, free, không cần API key.
            const seed = Math.floor(Math.random() * 1_000_000)
            const url = `${config.imageGenBaseURL}/${encodeURIComponent(prompt)}?width=1024&height=1024&seed=${seed}&nologo=true`

            const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 60_000 })
            const stream = Readable.from(Buffer.from(res.data))
            // ws3-fca cần stream có thuộc tính path/tên file để FB nhận diện đúng định dạng
            stream.path = 'imagine.png'

            return sendHuman(api, { body: `🖼️ "${prompt}"`, attachment: stream }, event.threadID, event.messageID)
        } catch (error) {
            console.error(error)
            api.sendMessage('❎ Có lỗi khi tạo ảnh, thử lại sau nhé.', event.threadID)
        } finally {
            startCooldown(userKey)
        config.ratelimit.delete(userKey)
        }
    }
}
