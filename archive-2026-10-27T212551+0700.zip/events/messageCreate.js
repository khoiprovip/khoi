const config = require('../config/config.js')
const { answer, collectImages } = require('../lib/ai.js')

/**
 * @arg {import('ws3-fca').API} api
 * @arg {object} event - Sự kiện nhận được từ api.listenMqtt
 */
module.exports = function(api, event) {
    if (event.type !== 'message' && event.type !== 'message_reply') return
    if (typeof event.body !== 'string') return

    const myId = api.getCurrentUserID()
    const isBot = event.senderID === myId

    // Tổng hợp tin nhắn của nhóm để làm ngữ cảnh cho lệnh /ask trả lời tốt hơn
    try {
        if (event.body.trim()) {
            const history = config.chatHistory.get(event.threadID) ?? []

            history.push({
                author: isBot ? 'Bot' : event.senderID,
                content: event.body,
                isBot
            })

            while (history.length > config.historyLimit) history.shift()

            config.chatHistory.set(event.threadID, history)
        }
    } catch (error) { console.error('Lỗi khi lưu lịch sử chat:', error) }

    // Theo dõi tin nhắn (chỉ nhóm đã bật /theodoi bat) để /tomtat tổng hợp
    try { require('../lib/tracker.js').record(event, isBot) } catch (error) { console.error('Lỗi tracker:', error.message) }

    if (isBot) return

    // Người đang bị /mute trong nhóm: bot phớt lờ hoàn toàn (không trả lời, không nhận lệnh, không bắt tag)
    try { if (event.isGroup !== false && require('../lib/muted.js').isMuted(event.threadID, event.senderID)) return } catch (error) { console.error('Lỗi mute:', error.message) }

    // Tự trả lời (không cần gõ /ask) khi: được @tag trong nhóm, HOẶC nhắn riêng (inbox) cho bot.
    // Lệnh có prefix vẫn được ưu tiên bên dưới.
    const isDM = event.isGroup === false
    const isMentioned = event.mentions && event.mentions[myId] !== undefined

    if (!event.body.startsWith(config.prefix) && (isMentioned || isDM)) {
        let text = event.body
        // Bỏ đoạn "@Tên Bot" khỏi nội dung câu hỏi
        const mentionName = isMentioned ? String(event.mentions[myId] || '').trim() : ''
        if (mentionName) text = text.split(mentionName).join(' ')
        text = text.replace(/\s+/g, ' ').trim()

        // Nhắn riêng mà chỉ là sticker/like (không chữ, không ảnh) thì bỏ qua
        if (isDM && !text && !collectImages(event).length) return

        answer(api, event, text).catch(error => console.error(error))
        return
    }

    if (!event.body.startsWith(config.prefix)) return

    const args = event.body.slice(config.prefix.length).trim().split(/\s+/g)
    const cmdName = args.shift().toLowerCase()
    const commandName = config.commands.has(cmdName) ? cmdName : config.aliases.get(cmdName)
    const command = config.commands.get(commandName)

    if (command) {
        try { command.run(api, event, args) }
        catch (error) { console.error(error) }
    }
}
