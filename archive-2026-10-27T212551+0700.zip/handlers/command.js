const fs = require('fs')
const path = require('path')
const config = require('../config/config.js')

module.exports = function() {
    let count = 0
    const commandsDir = path.join(__dirname, '..', 'commands')

    for (const category of fs.readdirSync(commandsDir)) {
        const categoryPath = path.join(commandsDir, category)
        if (!fs.statSync(categoryPath).isDirectory()) continue

        for (const file of fs.readdirSync(categoryPath)) {
            if (!file.endsWith('.js')) continue

            const command = require(path.join(categoryPath, file))
            config.commands.set(command.name, command)

            if (command.aliases) {
                for (const alias of command.aliases) config.aliases.set(alias, command.name)
            }

            count++
        }
    }

    console.log(`${count} lệnh đã sẵn sàng!`)
}
