// Chạy: AI_API_KEY=xxx node scripts/test-models.js [model1 model2 ...]
// Gửi cùng 1 bài toán cho từng model, in ra thời gian + câu trả lời để tự so sánh.
const axios = require('axios')

const BASE = process.env.AI_BASE || 'https://motapis.com/v1/chat/completions'
const KEY = process.env.AI_API_KEY
const MODELS = process.argv.slice(2).length ? process.argv.slice(2) : [
    'claude-sonnet-5-5', 'claude-sonnet-5', 'claude-sonnet-4-6', 'deepseek-v4-flash', 'glm-5.3-flash',
    'gpt-6-sol', 'gpt-6-luna', 'gpt-6-astra', 'gpt-5.6-sol', 'grok-4.6', 'grok-4.5',
    'hy4-preview', 'hy3', 'minimax-m3', 'minimax-m2.7', 'qwen3.8-max'
]
const PROMPT = 'Giải bằng tiếng Việt, ngắn gọn: Tam giác ABC vuông tại A, AB = 6, AC = 8. Tính BC, đường cao AH và diện tích. Không dùng LaTeX/Markdown. Đáp số cuối cùng ghi rõ.'
// Đáp án đúng: BC = 10, AH = 4,8, S = 24
const CORRECT = ['10', '4,8', '24']

;(async () => {
    if (!KEY) return console.error('Thiếu AI_API_KEY')
    for (const model of MODELS) {
        const t0 = Date.now()
        try {
            const res = await axios.post(BASE, { model, messages: [{ role: 'user', content: PROMPT }], max_tokens: 1500 },
                { headers: { Authorization: `Bearer ${KEY}` }, timeout: 90_000 })
            const text = (res.data.choices[0].message.content || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim()
            const ok = CORRECT.every(c => text.replace(/\./g, ',').includes(c))
            console.log(`\n=== ${model} | ${((Date.now() - t0) / 1000).toFixed(1)}s | ${ok ? 'ĐÚNG' : 'CHECK'} ===\n${text.slice(0, 600)}`)
        } catch (e) {
            console.log(`\n=== ${model} | LỖI: ${e.response?.data?.error?.message || e.response?.status || e.message}`)
        }
    }
})()
